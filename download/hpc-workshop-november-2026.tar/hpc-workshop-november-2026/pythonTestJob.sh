#!/bin/bash -l

############# SLURM SETTINGS #############
#SBATCH --job-name=hpc_workshop_python        # some descriptive job name of your choice
#SBATCH --reservation="sufrs-hpc-workshop_2026-11-13" # Needed to access the reserved resources for this workshop
#SBATCH --partition=cpu         # which partition to use, default "cpu"
#SBATCH --time=0-00:01:00       # time limit for the whole run, in the form of d-hh:mm:ss
#SBATCH --mem=1G                # memory required per node, in the form of [num][M|G|T]
#SBATCH --nodes=1               # number of nodes to allocate, default is 1
#SBATCH --cpus-per-task=1       # number of processor cores to be assigned for each task, default is 1, increase for multi-threaded runs
#SBATCH --ntasks-per-node=1     # number of tasks to be launched on each allocated node

############# SOFTWARE SETUP #############


############# MY CODE #############


