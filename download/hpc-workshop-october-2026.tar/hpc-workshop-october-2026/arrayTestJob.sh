#!/bin/bash -l

############# SLURM SETTINGS #############
#SBATCH --job-name=hpc_workshop_array        # some descriptive job name of your choice
#SBATCH --reservation="sufrs-hpc-workshop_2026-10-23" # Needed to access the reserved resources for this workshop
#SBATCH --partition=cpu         # which partition to use, default "cpu"
#SBATCH --time=0-00:03:00       # time limit for the whole run, in the form of d-hh:mm:ss
#SBATCH --mem=1G                # memory required per node, in the form of [num][M|G|T]
#SBATCH --nodes=1               # number of nodes to allocate, default is 1
#SBATCH --cpus-per-task=1       # number of processor cores to be assigned for each task, default is 1, increase for multi-threaded runs
#SBATCH --ntasks-per-node=1     # number of tasks to be launched on each allocated node
#SBATCH --array=1-3             # create job array of 3 tasks numbered 1 through 3

############# SOFTWARE SETUP #############
#module load xxx
#export PATH="$PATH:/mnt/home/guid/software/xxx/bin"

############# MY CODE #############
echo "Hello from $SLURM_JOB_NODELIST"
echo "This is task $SLURM_ARRAY_TASK_ID out of $SLURM_ARRAY_TASK_COUNT"
echo "Jobs are between $SLURM_ARRAY_TASK_MIN and $SLURM_ARRAY_TASK_MAX"
